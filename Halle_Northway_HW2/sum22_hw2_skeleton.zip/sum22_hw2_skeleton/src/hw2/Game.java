package hw2;


public class Game {

	public static final int DEFAULT_MAX_WRONG_GUESSES = 7;

	public Game(String word) {
		// TODO: 
	}

	
	public Game(String word, int maxGuesses) {
		// TODO: 
	}

	public int getMaxGuesses() {
		// TODO: 
		return 0;
	}

	public boolean gameOver() {
		// TODO: 
		return false;
	}

	public int numWrongGuesses() {
		// TODO: 
		return 0;
	}

	
	public boolean won() {
		// TODO: 
		return false;
	}

	public String lettersGuessed() {
		// TODO: 
		return "";
	}

	
	public HideableChar[] getDisplayedWord() {
		// TODO: 
		return null;
	}

	public String getSecretWord() {
		// TODO: 
		return "";
	}

	
	public boolean guessLetter(char ch) {
		// TODO: 
		return false;
	}
}
