package hw2;

public class HideableChar {
	
	public HideableChar(char ch) {
		// TODO: 
	}

	public boolean isHidden() {
		// TODO: 
		return false;
	}

	public void hide() {
		// TODO: 
	}

	public void unHide() {
		// TODO: 
	}

	public boolean matches(char ch) {
		// TODO: 
		return false;
	}

	public String getDisplayedChar() {
		// TODO: 
		return "";
	}

	public String getHiddenChar() {
		// TODO: 
		return "";
	}
}
