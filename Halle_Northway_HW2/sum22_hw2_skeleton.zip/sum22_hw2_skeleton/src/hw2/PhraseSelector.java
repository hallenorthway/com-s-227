package hw2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class PhraseSelector {
	
	public PhraseSelector(String givenFilename) throws FileNotFoundException {
		// TODO:
	}

	
	public String selectWord(Random rand) throws FileNotFoundException {
		// TODO:
		return "";
	}
}
