package hw2;
import static org.junit.Assert.assertTrue;

import org.junit.*;

public class HideableCharTest
{
	@Test
	public void testIsHidden()
	{
		HideableChar c = new HideableChar('a');
		assertTrue(c.isHidden());
	}
	
	// TODO: Write your test code below
}
