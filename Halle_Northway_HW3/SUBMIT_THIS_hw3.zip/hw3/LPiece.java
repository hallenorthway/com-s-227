package hw3;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Piece type that has a 3 x 3 bounding square with the icons at (0, 0), (0, 1),
 * (1, 1), and (2, 1), in that order.
 * 
 * @author Halle N
 */
public class LPiece extends AbstractPiece {
	
	/**
	 * Constructs a new LPiece with the given position and icons.
	 * 
	 * @param position
	 *   position of this piece
	 * @param icons
	 *   icons of this piece
	 */
	public LPiece(Position position, Icon[] icons) {
		super(position);
		Cell[] cells = new Cell[4];
		
		cells[0] = new Cell(new Icon(icons[0].getColorHint()), new Position(0, 0));
		cells[1] = new Cell(new Icon(icons[1].getColorHint()), new Position(0, 1));
		cells[2] = new Cell(new Icon(icons[2].getColorHint()), new Position(1, 1));	
		cells[3] = new Cell(new Icon(icons[3].getColorHint()), new Position(2, 1));
		
		super.setCells(cells);
	}

	/**
	 * Flips the cells horizontally across the vertical centerline of the bounding
	 * square.
	 */
	@Override
	public void transform() {
		
		Cell[] cells = super.getCells();
		
		if (cells[0].getRow() == 0 && cells[0].getCol() == 0) {
			cells[0].setRowCol(0, 2);
		} else if (cells[0].getRow() == 0 && cells[0].getCol() == 2) {
			cells[0].setRowCol(0, 0);
		}
		
		super.setCells(cells);
	}
}