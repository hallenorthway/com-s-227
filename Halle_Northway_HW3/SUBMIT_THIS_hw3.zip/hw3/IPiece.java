
package hw3;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Piece type that has a 3 x 3 bounding square with the icons down the center in the
 * order (0, 1), (1, 1), and (2, 1).
 * 
 * @author Halle N
 */
public class IPiece extends AbstractPiece {
	
	/**
	 * Constructs a new IPiece with the given position and icons.
	 * 
	 * @param position
	 *   position of this piece
	 * @param icons
	 *   icons of this piece
	 */
	public IPiece(Position position, Icon[] icons) {
		super(position);
		Cell[] cells = new Cell[3];
		
		cells[0] = new Cell(new Icon(icons[0].getColorHint()), new Position(0, 1));
		cells[1] = new Cell(new Icon(icons[1].getColorHint()), new Position(1, 1));
		cells[2] = new Cell(new Icon(icons[2].getColorHint()), new Position(2, 1));
		
		super.setCells(cells);
	}

	/**
	 * Does nothing.
	 */
	@Override
	public void transform() {
		// nothin' at all
	}
}