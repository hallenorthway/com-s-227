package hw3;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Piece type with a 3 x 3 bounding square and initial cell positions (0, 0),
 * (1, 0), (1, 1), and (1, 2) in that order.
 * 
 * @author Halle N
 */
public class SnakePiece extends AbstractPiece
{
	  /**
	   * Sequence of positions for the first cell.
	   */
	  private static final Position[] sequence = {
	      new Position(0, 0),
	      new Position(0, 1),
	      new Position(0, 2),
	      new Position(1, 2),
	      new Position(1, 1),
	      new Position(1, 0),
	      new Position(2, 0),
	      new Position(2, 1),
	      new Position(2, 2),
	      new Position(1, 2),
	      new Position(1, 1),
	      new Position(1, 0),
	  };
	      
	  /**
	   * Index used for sequence array to set cell position.
	   */
	  private int counter = 1;
	  
	  /**
	 * Constructs a new SnakePiece with the given position and icons.
	 * 
	 * @param position
	 *   position of this piece
	 * @param icons
	 *   icons of this piece
	   */
	  public SnakePiece(Position position, Icon[] icons) {
	    super(position);
	    Cell[] cells = new Cell[4];
	    
		cells[0] = new Cell(new Icon(icons[0].getColorHint()), new Position(0, 0));
		cells[1] = new Cell(new Icon(icons[1].getColorHint()), new Position(1, 0));
		cells[2] = new Cell(new Icon(icons[2].getColorHint()), new Position(1, 1));	
		cells[3] = new Cell(new Icon(icons[3].getColorHint()), new Position(1, 2));
	    
		super.setCells(cells);
	  }
	
	  /**
	   * Shifts cells forward in a specified sequence of positions.
	   */
	  @Override
	  public void transform() {	
	  
		Cell[] cells = super.getCells();

		int cell1 = counter;
		int cell2 = counter - 1;
		int cell3 = counter - 2;
		int cell4 = counter - 3;
		
		// check if any of them are out of bounds, if so, reassign
		if (cell2 < 0) {
			cell2 = 12 + cell2; 
		}
		if (cell3 < 0) {
			cell3 = 12 + cell3;
		}
		if (cell4 < 0) {
			cell4 = 12 + cell4; 
		}
		
		cells[0].setPosition(sequence[cell1]);
		cells[1].setPosition(sequence[cell2]);
		cells[2].setPosition(sequence[cell3]);
		cells[3].setPosition(sequence[cell4]);
		
		if (counter == 11) {
			counter = 0;
		} else {
			counter++;
		}
		
		super.setCells(cells);
  }
}