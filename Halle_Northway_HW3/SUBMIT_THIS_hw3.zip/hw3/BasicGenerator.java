package hw3;

import java.util.Random;

import api.Generator;
import api.Icon;
import api.Piece;
import api.Position;

/**
 * Generator for Piece objects in BlockAddiction. Icons are always selected
 * uniformly at random, and the Piece types are generated with different
 * probabilities.
 * 
 * @author Halle N
 */
public class BasicGenerator implements Generator {

	/**
	 * The random object.
	 */
	private Random rand;

	/**
	 * Constructs a BasicGenerator that will use the given Random object as its
	 * source of randomness.
	 * 
	 * @param
	 *   givenRandom instance of Random to use
	 */
	public BasicGenerator(Random givenRandom) {
		rand = givenRandom;
	}

	@Override
	public Piece getNext(int width) {
		int n = rand.nextInt(101);
		int col = width / 2 - 1;

		if (n > 0 && n <= 10) { // 10%
		    Icon[] icons = { 
		    	      randomIcon(),
		    	      randomIcon(),
		    	      randomIcon(),
		    	      randomIcon(),
		    	    };
			return new LPiece(new Position(-2, col), icons);
			
		} else if (n > 10 && n <= 35) { // 25%
		    Icon[] icons = { 
		    	      randomIcon(),
		    	      randomIcon(),
		    	    };
			return new DiagonalPiece(new Position(-1, col), icons);
			
		} else if (n > 35 && n <= 50) { // 15%
		    Icon[] icons = { 
		    	      randomIcon(),
		    	      randomIcon(),
		    	      randomIcon(),
		    	    };
			return new CornerPiece(new Position(-1, col), icons);
			
		} else if (n > 50 && n <= 60) { // 10%
		    Icon[] icons = { 
		    	      randomIcon(),
		    	      randomIcon(),
		    	      randomIcon(),
		    	      randomIcon(),
		    	    };
			return new SnakePiece(new Position(-1, col), icons);
			
		} else if (n > 60 && n <= 100) { // 40%
		    Icon[] icons = { 
		    	      randomIcon(),
		    	      randomIcon(),
		    	      randomIcon(),
		    	    };
			return new IPiece(new Position(-2, col), icons);
			
		} else {
			return null;
		}
	}

	@Override
	public Icon randomIcon() {
		return new Icon(Icon.COLORS[rand.nextInt(Icon.COLORS.length)]);
	}
}
