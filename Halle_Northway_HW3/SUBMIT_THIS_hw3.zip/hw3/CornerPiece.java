package hw3;

import api.Cell;
import api.Icon;
import api.Position;

/**
 * Piece type with a 2 x 2 bounding square and initial cell positions (0, 0), (1, 0),
 * and (1, 1) in that order.
 * 
 * @author Halle N
 */

public class CornerPiece extends AbstractPiece {
	
	/**
	 * Constructs a new CornerPiece with the given position and icons.
	 * 
	 * @param position
	 *   position of this piece
	 * @param icons
	 *   icons of this piece
	 */
	public CornerPiece(Position position, Icon[] icons) {
		super(position);
		Cell[] cells = new Cell[3];
		
		cells[0] = new Cell(new Icon(icons[0].getColorHint()), new Position(0, 0));
		cells[1] = new Cell(new Icon(icons[1].getColorHint()), new Position(1, 0));
		cells[2] = new Cell(new Icon(icons[2].getColorHint()), new Position(1, 1));
		
		super.setCells(cells);
	}

	/**
	 * Shifts the cells following the sequence (0, 0), (0, 1), (1, 1), (1, 0).
	 */
	@Override
	public void transform() {
		
		Cell[] cells = super.getCells();

		if (cells[0].getRow() == 0 && cells[0].getCol() == 0) {
			cells[0].setRowCol(0, 1);
			cells[1].setRowCol(0, 0);
			cells[2].setRowCol(1, 0);
		} else if (cells[0].getRow() == 0 && cells[0].getCol() == 1) {
			cells[0].setRowCol(1, 1);
			cells[1].setRowCol(0, 1);
			cells[2].setRowCol(0, 0);
		} else if (cells[0].getRow() == 1 && cells[0].getCol() == 1) {
			cells[0].setRowCol(1, 0);
			cells[1].setRowCol(1, 1);
			cells[2].setRowCol(0, 1);
		} else if (cells[0].getRow() == 1 && cells[0].getCol() == 0) {
			cells[0].setRowCol(0, 0);
			cells[1].setRowCol(1, 0);
			cells[2].setRowCol(1, 1);
		}
		
		super.setCells(cells);

	}
}

