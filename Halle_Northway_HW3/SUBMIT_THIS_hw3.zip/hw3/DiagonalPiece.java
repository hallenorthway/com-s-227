package hw3;

import api.Icon;
import api.Cell;
import api.Position;

/**
 * Piece type that has a 2 x 2 bounding square with the icons at (0, 0) and, (1, 1),
 * in that order.
 * 
 * @author Halle N
 */

public class DiagonalPiece extends AbstractPiece {
	
	/**
	 * Constructs a new DiagonalPiece with the given position and icons.
	 * 
	 * @param position
	 *   position of this piece
	 * @param icons
	 *   icons of this piece
	 */
	public DiagonalPiece(Position position, Icon[] icons) {
		super(position);
		Cell[] cells = new Cell[2];
		
		cells[0] = new Cell(new Icon(icons[0].getColorHint()), new Position(0, 0));
		cells[1] = new Cell(new Icon(icons[1].getColorHint()), new Position(1, 1));
		
		super.setCells(cells);
	}

	/**
	 * Flips the cells across the vertical centerline of the bounding square.
	 */
	@Override
	public void transform() {
		
		Cell[] cells = super.getCells();

		if (cells[0].getRow() == 0 && cells[0].getCol() == 0) {
			cells[0].setRowCol(0, 1);
			cells[1].setRowCol(1, 0);
		} else if (cells[0].getRow() == 0 && cells[0].getCol() == 1) {
			cells[0].setRowCol(0, 0);
			cells[1].setRowCol(1, 1);
		}
		
		super.setCells(cells);

	}
}

