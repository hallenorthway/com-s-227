package hw3;

import api.Icon;
import api.Cell;
import api.Position;
import examples.SamplePiece;
import api.Piece;

/**
 * Abstract superclass for implementations of the Piece interface.
 */
public abstract class AbstractPiece implements Piece {
	
	protected Cell[] cells;

	/**
	 * Constructs a piece with the given position. Subclasses extending this class
	 * MUST call setCells to initialize initial cell positions and icons.
	 * 
	 * @param position initial position for upper-left corner of bounding box
	 */
	protected AbstractPiece(Position position) {
		// TODO Auto-generated method stub
	}

	@Override
	public Position getPosition() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setCells(Cell[] givenCells) {
		// TODO Auto-generated method stub

	}

	@Override
	public Cell[] getCells() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cell[] getCellsAbsolute() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void shiftDown() {
		// TODO Auto-generated method stub

	}

	@Override
	public void shiftLeft() {
		// TODO Auto-generated method stub

	}

	@Override
	public void shiftRight() {
		// TODO Auto-generated method stub

	}

	@Override
	public void cycle() {
		// TODO Auto-generated method stub

	}

	@Override
	public Piece clone() {
		try
		{
			// call the Object clone() method to create a shallow copy
			AbstractPiece s = (AbstractPiece) super.clone();

			// then make it into a deep copy (note there is no need to copy the position,
			// since Position is immutable, but we have to deep-copy the cell array
			// by making new Cell objects
			s.cells = new Cell[2];
			for (int i = 0; i < cells.length; ++i)
			{
				s.cells[i] = new Cell(cells[i]);
			}
			return s;
		}
		catch (CloneNotSupportedException e)
		{
			// can't happen, since we know the superclass is cloneable
			return null;
		}
	}

}