package hw3;

import api.Cell;
import api.Icon;
import api.Position;

public class CornerPiece extends AbstractPiece {

	public CornerPiece(Position position, Icon[] icons) {
		super(position);
		// TODO:
	}

	@Override
	public void transform() {
		// TODO:
	}
}
